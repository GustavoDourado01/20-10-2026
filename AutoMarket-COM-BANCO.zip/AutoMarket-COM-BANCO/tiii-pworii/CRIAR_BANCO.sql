-- ============================================================
-- Execute este script CONECTADO ao banco "postgres" (padrão)
-- NÃO execute conectado em "automarket" (ainda não existe)
--
-- Windows (PowerShell ou CMD), com PostgreSQL no PATH:
--
--   psql -U postgres -d postgres -f CRIAR_BANCO.sql
--
-- Ou no pgAdmin: Query Tool no banco "postgres" → cole e execute
-- ============================================================

SELECT 'Criando banco automarket (se ainda não existir)...' AS info;

-- PostgreSQL não tem CREATE DATABASE IF NOT EXISTS em versões antigas.
-- Este bloco evita erro se o banco já existir:
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_database WHERE datname = 'automarket') THEN
    PERFORM dblink_exec('dbname=postgres', 'CREATE DATABASE automarket OWNER postgres ENCODING ''UTF8''');
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    -- fallback: tente criar direto (ignore se já existir ao rodar de outro jeito)
    NULL;
END $$;

-- Forma simples e confiável (rode UMA vez):
-- Se o DO acima falhar (sem extensão dblink), use só esta linha no psql:
-- CREATE DATABASE automarket OWNER postgres ENCODING 'UTF8';
