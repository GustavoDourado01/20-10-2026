-- Rode no banco "postgres":
CREATE DATABASE automarket OWNER postgres ENCODING 'UTF8';
