-- Dados iniciais (idempotente — pode rodar mais de uma vez)
INSERT INTO usuario (nome, sobrenome, email, senha, telefone, cpf, cidade, estado, tipo, bio)
VALUES
('Daniel', 'Lucena', 'daniel.lucena@ifg.edu.br', '123456', '(62) 99999-0001', '111.111.111-11', 'Luziânia', 'GO', 'admin', 'Administrador do sistema'),
('Maria', 'Silva', 'maria@automarket.com', '123456', '(11) 98888-0002', '222.222.222-22', 'São Paulo', 'SP', 'vendedor', 'Vendedora de veículos'),
('João', 'Santos', 'joao@automarket.com', '123456', '(21) 97777-0003', '333.333.333-33', 'Rio de Janeiro', 'RJ', 'cliente', 'Cliente interessado em carros')
ON CONFLICT (email) DO NOTHING;

INSERT INTO veiculo (marca, modelo, versao, ano, km, preco, cambio, combustivel, cor, potencia, cidade, estado, descricao, telefone, criado_em, usuario_id)
SELECT 'Volkswagen', 'Polo', '200 TSI Comfortline', 2023, 12800, 89900, 'automatico', 'flex', 'Preto', 116, 'São Paulo', 'SP', 'Polo TSI impecável, único dono.', '(11) 99999-0001', CURRENT_TIMESTAMP, u.id
FROM usuario u WHERE u.email = 'maria@automarket.com'
AND NOT EXISTS (SELECT 1 FROM veiculo v WHERE v.marca = 'Volkswagen' AND v.modelo = 'Polo' AND v.ano = 2023);

INSERT INTO veiculo (marca, modelo, versao, ano, km, preco, cambio, combustivel, cor, potencia, cidade, estado, descricao, telefone, criado_em, usuario_id)
SELECT 'Fiat', 'Argo', 'Drive 1.3', 2022, 28500, 62500, 'manual', 'flex', 'Branco', 109, 'Goiânia', 'GO', 'Argo Drive em ótimo estado.', '(62) 99999-0002', CURRENT_TIMESTAMP, u.id
FROM usuario u WHERE u.email = 'maria@automarket.com'
AND NOT EXISTS (SELECT 1 FROM veiculo v WHERE v.marca = 'Fiat' AND v.modelo = 'Argo' AND v.ano = 2022);

INSERT INTO veiculo (marca, modelo, versao, ano, km, preco, cambio, combustivel, cor, potencia, cidade, estado, descricao, telefone, criado_em, usuario_id)
SELECT 'Toyota', 'Corolla', 'XEi 2.0', 2021, 42000, 118900, 'automatico', 'flex', 'Prata', 177, 'Curitiba', 'PR', 'Corolla XEi completo, revisões em dia.', '(41) 99999-0003', CURRENT_TIMESTAMP, u.id
FROM usuario u WHERE u.email = 'daniel.lucena@ifg.edu.br'
AND NOT EXISTS (SELECT 1 FROM veiculo v WHERE v.marca = 'Toyota' AND v.modelo = 'Corolla' AND v.ano = 2021);
