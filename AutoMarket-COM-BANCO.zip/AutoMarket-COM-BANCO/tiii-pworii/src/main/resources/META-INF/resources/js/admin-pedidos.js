// Admin pedidos — lista e atualiza status no PostgreSQL

function formatMoney(v) {
  return Number(v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function formatDate(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleString('pt-BR', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}

function badgeStatus(status) {
  const map = {
    pendente: 'badge-pendente',
    aprovado: 'badge-aprovado',
    rejeitado: 'badge-rejeitado'
  };
  return `<span class="badge ${map[status] || 'badge-info'}">${status || '—'}</span>`;
}

function labelPagamento(v) {
  const map = {
    avista: 'À vista',
    'a vista': 'À vista',
    financiamento: 'Financiamento',
    consorcio: 'Consórcio',
    permuta: 'Permuta + dinheiro'
  };
  return map[v] || v || '—';
}

function mapPedido(p) {
  const veiculo = p.veiculo || {};
  const usuario = p.usuario || {};
  return {
    id: p.id,
    status: p.status,
    valorProposta: p.valorProposta,
    formaPagamento: p.formaPagamento,
    mensagem: p.mensagem,
    criadoEm: p.criadoEm,
    veiculoLabel: `${veiculo.marca || ''} ${veiculo.modelo || ''} ${veiculo.ano || ''}`.trim() || 'Veículo',
    veiculoPreco: veiculo.preco,
    clienteNome: usuario.nome ? `${usuario.nome} ${usuario.sobrenome || ''}`.trim() : 'Cliente',
    clienteEmail: usuario.email || '—',
    clienteTelefone: usuario.telefone || '—'
  };
}

function renderPedidosAdmin() {
  const container = document.getElementById('lista-admin') || document.getElementById('lista-pedidos') || document.getElementById('pedidos-admin');
  if (!container) return;

  const filtro = document.getElementById('filtro-status')?.value || '';

  fetch('/admin-pedidos/listar')
    .then(r => {
      if (!r.ok) throw new Error('Falha ao listar pedidos');
      return r.json();
    })
    .then(lista => {
      let pedidos = (Array.isArray(lista) ? lista : []).map(mapPedido);
      if (filtro) pedidos = pedidos.filter(p => p.status === filtro);

      if (pedidos.length === 0) {
        container.innerHTML = `
          <div class="empty-state">
            <div class="icon">✅</div>
            <h3>Nenhum pedido neste filtro</h3>
            <p>Quando clientes enviarem pedidos, eles aparecerão aqui (dados do banco).</p>
          </div>`;
        return;
      }

      container.innerHTML = pedidos.map(p => `
        <div class="pedido-card">
          <div class="pedido-card-header">
            <div>
              <h3>${p.veiculoLabel}</h3>
              <small style="color:var(--muted)">Pedido #${p.id}</small>
            </div>
            ${badgeStatus(p.status)}
          </div>
          <div class="pedido-meta">
            <span>👤 ${p.clienteNome}</span>
            <span>📧 ${p.clienteEmail}</span>
            <span>📱 ${p.clienteTelefone}</span>
            <span>💰 Proposta: <strong>${formatMoney(p.valorProposta)}</strong></span>
            <span>🏷️ Anúncio: ${formatMoney(p.veiculoPreco)}</span>
            <span>💳 ${labelPagamento(p.formaPagamento)}</span>
            <span>📅 ${formatDate(p.criadoEm)}</span>
          </div>
          ${p.mensagem ? `<p style="font-size:.9rem;color:var(--gray2);margin-bottom:12px">Mensagem: “${p.mensagem}”</p>` : ''}
          ${p.status === 'pendente' ? `
            <div class="pedido-actions">
              <button class="btn-success" onclick="aprovarPedido(${p.id})">✓ Aprovar</button>
              <button class="btn-danger" onclick="rejeitarPedido(${p.id})">✕ Rejeitar</button>
            </div>
          ` : ''}
        </div>
      `).join('');
    })
    .catch(err => {
      console.error(err);
      container.innerHTML = `<p style="color:#b91c1c">Erro ao carregar pedidos do banco.</p>`;
    });
}

function atualizarStatusPedido(id, status) {
  let adminNome = 'Admin';
  let adminEmail = '';
  try {
    const s = JSON.parse(localStorage.getItem('automarket_session') || 'null');
    if (s) {
      adminNome = [s.nome, s.sobrenome].filter(Boolean).join(' ') || s.nome || 'Admin';
      adminEmail = s.email || '';
    }
  } catch {}
  const qs = new URLSearchParams({ adminNome, adminEmail }).toString();
  fetch('/admin-pedidos/atualizar-status?' + qs, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id, status })
  })
    .then(async (r) => {
      const data = await r.json().catch(() => ({}));
      if (!r.ok) {
        alert(typeof data === 'string' ? data : (data.erro || 'Erro ao atualizar status.'));
        return;
      }
      alert(`Pedido #${id} atualizado para: ${status}`);
      renderPedidosAdmin();
    })
    .catch(err => {
      console.error(err);
      alert('Erro de conexão com o servidor.');
    });
}

function aprovarPedido(id) {
  atualizarStatusPedido(id, 'aprovado');
}

function rejeitarPedido(id) {
  if (!confirm('Rejeitar este pedido?')) return;
  atualizarStatusPedido(id, 'rejeitado');
}

document.addEventListener('DOMContentLoaded', () => {
  renderPedidosAdmin();
  const filtro = document.getElementById('filtro-status');
  if (filtro) filtro.addEventListener('change', renderPedidosAdmin);
});
