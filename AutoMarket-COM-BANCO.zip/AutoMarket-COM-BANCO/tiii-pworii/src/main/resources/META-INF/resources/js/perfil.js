// Configuração de Perfil

function carregarPerfil() {
  const p = getPerfil();
  document.getElementById('nome').value = p.nome || '';
  document.getElementById('email').value = p.email || '';
  document.getElementById('telefone').value = p.telefone || '';
  document.getElementById('cpf').value = p.cpf || '';
  document.getElementById('cidade').value = p.cidade || '';
  document.getElementById('estado').value = p.estado || '';
  document.getElementById('tipo').value = p.tipo || 'cliente';
  document.getElementById('bio').value = p.bio || '';
  document.getElementById('senha-atual').value = '';
  document.getElementById('senha-nova').value = '';
  atualizarSidebar();
}

function salvarPerfil(e) {
  e.preventDefault();

  const perfil = {
    nome: document.getElementById('nome').value.trim(),
    email: document.getElementById('email').value.trim(),
    telefone: document.getElementById('telefone').value.trim(),
    cpf: document.getElementById('cpf').value.trim(),
    cidade: document.getElementById('cidade').value.trim(),
    estado: document.getElementById('estado').value,
    tipo: document.getElementById('tipo').value,
    bio: document.getElementById('bio').value.trim()
  };

  if (!perfil.nome || !perfil.email) {
    showAlert('Nome e e-mail são obrigatórios.', 'error');
    return false;
  }

  const senhaNova = document.getElementById('senha-nova').value;
  if (senhaNova) {
    if (senhaNova.length < 6) {
      showAlert('A nova senha deve ter pelo menos 6 caracteres.', 'error');
      return false;
    }
    perfil.senhaAlteradaEm = new Date().toISOString();
  }

  setPerfil(perfil);
  registrarLog('ATUALIZAR_PERFIL', `Perfil atualizado: ${perfil.nome} (${perfil.email}) — tipo: ${perfil.tipo}`);
  showAlert('Perfil atualizado com sucesso!');
  atualizarSidebar();
  return false;
}

document.addEventListener('DOMContentLoaded', carregarPerfil);
