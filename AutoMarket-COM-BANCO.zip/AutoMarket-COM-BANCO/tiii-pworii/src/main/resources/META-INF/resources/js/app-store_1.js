// ===========================
// AUTOMARKET — APP STORE (localStorage)
// Simula backend para os casos de uso
// ===========================

const STORE_KEYS = {
  veiculos: 'am_veiculos',
  pedidos: 'am_pedidos',
  perfil: 'am_perfil',
  logs: 'am_logs',
  usuario: 'am_usuario'
};

function getStore(key) {
  try {
    return JSON.parse(localStorage.getItem(key) || '[]');
  } catch {
    return [];
  }
}

function setStore(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}

function getPerfil() {
  try {
    const p = localStorage.getItem(STORE_KEYS.perfil);
    if (p) return JSON.parse(p);
  } catch {}
  return {
    nome: 'Usuário Demo',
    email: 'demo@automarket.com',
    telefone: '(11) 99999-0000',
    cpf: '',
    cidade: 'São Paulo',
    estado: 'SP',
    tipo: 'cliente',
    bio: ''
  };
}

function setPerfil(perfil) {
  localStorage.setItem(STORE_KEYS.perfil, JSON.stringify(perfil));
}

function getUsuarioAtual() {
  return getPerfil();
}

function registrarLog(acao, detalhes) {
  const logs = getStore(STORE_KEYS.logs);
  const user = getUsuarioAtual();
  logs.unshift({
    id: Date.now() + Math.random().toString(36).slice(2, 7),
    data: new Date().toISOString(),
    usuario: user.nome || user.email || 'Anônimo',
    email: user.email || '',
    acao,
    detalhes: typeof detalhes === 'string' ? detalhes : JSON.stringify(detalhes),
    origem: 'web'
  });
  // mantém no máximo 500 logs
  if (logs.length > 500) logs.length = 500;
  setStore(STORE_KEYS.logs, logs);
}

function formatMoney(v) {
  return Number(v).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function formatDate(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleString('pt-BR', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}

function badgeStatus(status) {
  const map = {
    pendente: 'badge-pendente',
    aprovado: 'badge-aprovado',
    rejeitado: 'badge-rejeitado'
  };
  return `<span class="badge ${map[status] || 'badge-info'}">${status}</span>`;
}

function maskPhone(input) {
  let v = input.value.replace(/\D/g, '').slice(0, 11);
  if (v.length <= 10) {
    v = v.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3');
  } else {
    v = v.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3');
  }
  input.value = v;
}

function maskCpf(input) {
  let v = input.value.replace(/\D/g, '').slice(0, 11);
  v = v.replace(/(\d{3})(\d)/, '$1.$2')
       .replace(/(\d{3})(\d)/, '$1.$2')
       .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  input.value = v;
}

function showAlert(msg, type = 'success') {
  const el = document.getElementById('alert');
  if (!el) return;
  el.className = 'alert alert-' + type;
  el.textContent = msg;
  el.style.display = 'block';
  setTimeout(() => { el.style.display = 'none'; }, 4500);
}

function atualizarSidebar() {
  const u = getUsuarioAtual();
  const av = document.getElementById('user-avatar');
  const nm = document.getElementById('user-name');
  const rl = document.getElementById('user-role');
  if (av) av.textContent = (u.nome || 'U').charAt(0).toUpperCase();
  if (nm) nm.textContent = u.nome || 'Usuário';
  if (rl) {
    const labels = { cliente: 'Cliente', vendedor: 'Vendedor', admin: 'Admin' };
    rl.textContent = labels[u.tipo] || u.tipo || 'Usuário';
  }
}

// Seed inicial de veículos se vazio
function ensureSeedVeiculos() {
  let veiculos = getStore(STORE_KEYS.veiculos);
  if (veiculos.length === 0) {
    veiculos = [
      {
        id: 1,
        marca: 'Volkswagen',
        modelo: 'Polo',
        versao: '200 TSI Comfortline',
        ano: 2023,
        km: 12800,
        preco: 89900,
        cambio: 'automatico',
        combustivel: 'flex',
        cor: 'Preto',
        potencia: 116,
        cidade: 'São Paulo',
        estado: 'SP',
        descricao: 'Polo TSI impecável, único dono.',
        telefone: '(11) 99999-0001',
        criadoEm: new Date().toISOString()
      },
      {
        id: 2,
        marca: 'Fiat',
        modelo: 'Argo',
        versao: 'Drive 1.3',
        ano: 2022,
        km: 28500,
        preco: 62500,
        cambio: 'manual',
        combustivel: 'flex',
        cor: 'Branco',
        potencia: 109,
        cidade: 'Goiânia',
        estado: 'GO',
        descricao: 'Argo Drive em ótimo estado.',
        telefone: '(62) 99999-0002',
        criadoEm: new Date().toISOString()
      },
      {
        id: 3,
        marca: 'Toyota',
        modelo: 'Corolla',
        versao: 'XEi 2.0',
        ano: 2021,
        km: 42000,
        preco: 118900,
        cambio: 'automatico',
        combustivel: 'flex',
        cor: 'Prata',
        potencia: 177,
        cidade: 'Curitiba',
        estado: 'PR',
        descricao: 'Corolla XEi completo, revisões em dia.',
        telefone: '(41) 99999-0003',
        criadoEm: new Date().toISOString()
      }
    ];
    setStore(STORE_KEYS.veiculos, veiculos);
  }
  return veiculos;
}

document.addEventListener('DOMContentLoaded', () => {
  ensureSeedVeiculos();
  atualizarSidebar();
});
