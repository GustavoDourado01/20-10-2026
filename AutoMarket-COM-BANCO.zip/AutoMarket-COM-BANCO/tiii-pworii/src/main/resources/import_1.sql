INSERT INTO usuario (nome, sobrenome, email, senha, telefone, cpf, cidade, estado, tipo, bio) VALUES
('Daniel', 'Lucena', 'daniel.lucena@ifg.edu.br', '123456', '(62) 99999-0001', '111.111.111-11', 'Luziânia', 'GO', 'admin', 'Administrador do sistema'),
('Maria', 'Silva', 'maria@automarket.com', '123456', '(11) 98888-0002', '222.222.222-22', 'São Paulo', 'SP', 'vendedor', 'Vendedora de veículos'),
('João', 'Santos', 'joao@automarket.com', '123456', '(21) 97777-0003', '333.333.333-33', 'Rio de Janeiro', 'RJ', 'cliente', 'Cliente interessado em carros');

INSERT INTO veiculo (marca, modelo, versao, ano, km, preco, cambio, combustivel, cor, potencia, cidade, estado, descricao, telefone, criado_em, usuario_id) VALUES
('Volkswagen', 'Polo', '200 TSI Comfortline', 2023, 12800, 89900, 'automatico', 'flex', 'Preto', 116, 'São Paulo', 'SP', 'Polo TSI impecável, único dono.', '(11) 99999-0001', NOW(), 2),
('Fiat', 'Argo', 'Drive 1.3', 2022, 28500, 62500, 'manual', 'flex', 'Branco', 109, 'Goiânia', 'GO', 'Argo Drive em ótimo estado.', '(62) 99999-0002', NOW(), 2),
('Toyota', 'Corolla', 'XEi 2.0', 2021, 42000, 118900, 'automatico', 'flex', 'Prata', 177, 'Curitiba', 'PR', 'Corolla XEi completo, revisões em dia.', '(41) 99999-0003', NOW(), 1);

INSERT INTO pedido (veiculo_id, usuario_id, valor_proposta, forma_pagamento, mensagem, status, criado_em) VALUES
(1, 3, 85000, 'financiamento', 'Tenho interesse, posso visitar a loja?', 'pendente', NOW()),
(2, 3, 60000, 'a vista', 'Proposta à vista.', 'pendente', NOW());

INSERT INTO log_auditoria (data, usuario, email, acao, detalhes, origem) VALUES
(NOW(), 'Daniel Lucena', 'daniel.lucena@ifg.edu.br', 'LOGIN', 'Login realizado com sucesso', 'web'),
(NOW(), 'Maria Silva', 'maria@automarket.com', 'CADASTRO_VEICULO', 'Cadastrou Volkswagen Polo 2023', 'web'),
(NOW(), 'João Santos', 'joao@automarket.com', 'PEDIDO_COMPRA', 'Enviou proposta para veículo id=1', 'web');
